"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"
import { ImageComparisonSlider } from "@/components/image-comparison-slider"

const projects = [
  {
    id: 1,
    title: "Complete Deck Transformation",
    category: "Decks",
    before: "/images/before-1.jpg",
    after: "/images/after-1.jpg",
    description:
      "Replaced aging red-painted deck with premium composite decking, modern black aluminum railings, and a stunning curved paver stone pathway.",
  },
  {
    id: 2,
    title: "Modern Deck Upgrade",
    category: "Decks",
    before: "/images/before-2.jpg",
    after: "/images/after-2.jpg",
    description:
      "Transformed worn deck surface into elegant composite decking with architectural diagonal patterns and sleek black railings.",
  },
  {
    id: 3,
    title: "Stairway & Landing Redesign",
    category: "Decks",
    before: "/images/before-3.jpg",
    after: "/images/after-3.jpg",
    description:
      "New composite stairs with picture-frame details, solar post caps, and herringbone pattern paver landing.",
  },
  {
    id: 4,
    title: "Sunroom Renovation",
    category: "Interior",
    before: "/images/before-4.jpg",
    after: "/images/after-4.jpg",
    description:
      "Dated sunroom transformed with luxury vinyl plank flooring, shiplap accent wall, and a stunning electric fireplace.",
  },
  {
    id: 5,
    title: "Fire Pit Patio Installation",
    category: "Hardscaping",
    before: "/images/before-5.jpg",
    after: "/images/after-5.jpg",
    description:
      "Created an elegant paver pathway with charcoal border leading to a circular stone fire pit patio.",
  },
  {
    id: 6,
    title: "Master Bathroom Remodel",
    category: "Bathrooms",
    before: "/images/before-6.jpg",
    after: "/images/after-6.jpg",
    description:
      "Complete bathroom renovation with marble-look tile, sleek black vanity, and modern walk-in shower.",
  },
  {
    id: 7,
    title: "Luxury Shower Upgrade",
    category: "Bathrooms",
    before: "/images/before-7.jpg",
    after: "/images/after-7.jpg",
    description:
      "Cramped shower stall converted to spa-worthy walk-in with rain showerhead, marble tile, and ambient lighting.",
  },
  {
    id: 8,
    title: "Bathroom Suite Renovation",
    category: "Bathrooms",
    before: "/images/before-8.jpg",
    after: "/images/after-8.jpg",
    description:
      "Removed dated garden tub and transformed space into a modern bathroom with marble floors and recessed lighting.",
  },
]

const categories = ["All", "Decks", "Bathrooms", "Hardscaping", "Interior"]

export function ProjectsSection() {
  const [activeCategory, setActiveCategory] = useState("All")

  const filteredProjects =
    activeCategory === "All"
      ? projects
      : projects.filter((p) => p.category === activeCategory)

  return (
    <section id="projects" className="py-24 bg-muted">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <p className="text-sm uppercase tracking-[0.2em] text-primary mb-4">
            Our Portfolio
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-foreground text-balance">
            Before & After Transformations
          </h2>
          <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
            See the dramatic difference quality craftsmanship makes. 
            Drag the slider to reveal each transformation.
          </p>
        </div>

        {/* Category Filter */}
        <div className="mt-10 flex flex-wrap justify-center gap-2">
          {categories.map((category) => (
            <button
              key={category}
              type="button"
              onClick={() => setActiveCategory(category)}
              className={cn(
                "px-5 py-2 rounded-full text-sm font-medium transition-all",
                activeCategory === category
                  ? "bg-primary text-primary-foreground"
                  : "bg-card text-foreground hover:bg-card/80"
              )}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="group overflow-hidden rounded-lg bg-card shadow-lg"
            >
              <ImageComparisonSlider
                beforeImage={project.before}
                afterImage={project.after}
                beforeAlt={`${project.title} - Before`}
                afterAlt={`${project.title} - After`}
              />
              <div className="p-4 sm:p-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-2">
                  <h3 className="font-serif text-lg sm:text-xl text-foreground">
                    {project.title}
                  </h3>
                  <span className="self-start px-3 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                    {project.category}
                  </span>
                </div>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {project.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
