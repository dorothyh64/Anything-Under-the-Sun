import { Home, Bath, Fence, Trees, Hammer, HardHat } from "lucide-react"

const services = [
  {
    icon: Home,
    title: "New Home Construction",
    description:
      "From foundation to finish, we build custom homes that reflect your lifestyle and exceed your expectations.",
  },
  {
    icon: Fence,
    title: "Custom Decks",
    description:
      "Premium composite and wood decks with modern railings, perfect for Michigan outdoor living.",
  },
  {
    icon: Bath,
    title: "Bathroom Remodels",
    description:
      "Transform outdated bathrooms into spa-worthy retreats with luxury finishes and expert craftsmanship.",
  },
  {
    icon: Hammer,
    title: "Kitchen Renovations",
    description:
      "Modern kitchens designed for function and beauty, from cabinetry to countertops.",
  },
  {
    icon: Trees,
    title: "Paver Patios & Hardscaping",
    description:
      "Elegant stone pathways, fire pits, and outdoor living spaces that extend your home into nature.",
  },
  {
    icon: HardHat,
    title: "Roofing & Siding",
    description:
      "Protect your investment with quality roofing, siding, and exterior improvements built to last.",
  },
]

export function ServicesSection() {
  return (
    <section id="services" className="py-24 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <p className="text-sm uppercase tracking-[0.2em] text-accent mb-4">
            What We Do
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-foreground text-balance">
            Full-Service Construction Excellence
          </h2>
          <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
            Whether you&apos;re dreaming of a new outdoor oasis or a complete home transformation, 
            we bring expertise, quality materials, and dedicated craftsmanship to every project.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.title}
              className="group p-8 bg-card rounded-lg border border-border hover:border-primary/30 hover:shadow-lg transition-all duration-300"
            >
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                <service.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-serif text-xl text-foreground mb-3">
                {service.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
