import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center pt-20 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/images/michigan-countryside.jpg"
          alt="Southwest Michigan countryside"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/50" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-32 text-center">
        <p className="text-sm uppercase tracking-[0.2em] text-primary-foreground/80 mb-6">
          Southwest Michigan&apos;s Trusted Builders
        </p>
        <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-primary-foreground leading-tight text-balance max-w-4xl mx-auto">
          Building Dreams,
          <br />
          Crafting Excellence
        </h1>
        <p className="mt-6 text-lg sm:text-xl text-primary-foreground/90 max-w-2xl mx-auto leading-relaxed text-pretty">
          From custom decks to stunning bathroom remodels - 
          Northbound Builders bring your dreams to life!
        </p>
        <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            asChild
            size="lg"
            className="bg-card text-foreground hover:bg-card/90 text-base px-8"
          >
            <Link href="#contact">
              Start Your Project
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="border-2 border-primary-foreground text-primary-foreground hover:bg-primary-foreground/10 text-base px-8 bg-transparent"
          >
            <Link href="#projects">View Our Work</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
