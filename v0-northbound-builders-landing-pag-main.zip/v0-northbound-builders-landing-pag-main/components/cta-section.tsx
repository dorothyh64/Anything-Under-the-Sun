import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Phone } from "lucide-react"

export function CtaSection() {
  return (
    <section className="py-20 bg-accent">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="text-center lg:text-left">
            <h2 className="font-serif text-3xl sm:text-4xl text-accent-foreground text-balance">
              Let&apos;s Build Something Beautiful Together
            </h2>
            <p className="mt-3 text-accent-foreground/80 text-lg max-w-xl">
              Ready to transform your home? Get in touch today for a free consultation and estimate.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <Button
              asChild
              size="lg"
              className="bg-card text-foreground hover:bg-card/90 text-base px-8"
            >
              <Link href="#contact">
                Get Your Free Quote
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="border-accent-foreground/30 text-accent-foreground hover:bg-accent-foreground/10 text-base px-8 bg-transparent"
            >
              <a href="tel:+12693550968">
                <Phone className="mr-2 h-4 w-4" />
                Call Now
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
