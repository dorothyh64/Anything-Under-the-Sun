import Image from "next/image"
import { Heart, Award, Users, MapPin } from "lucide-react"

const values = [
  {
    icon: Heart,
    title: "Family Values",
    description: "We treat every project like it's our own home.",
  },
  {
    icon: Award,
    title: "Quality First",
    description: "Premium materials and expert craftsmanship, always.",
  },
  {
    icon: Users,
    title: "Personal Touch",
    description: "Direct communication with Jon and Brandi throughout.",
  },
  {
    icon: MapPin,
    title: "Local Pride",
    description: "Proud to build better homes across Southwest Michigan.",
  },
]

export function AboutSection() {
  return (
    <section id="about" className="py-24 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image */}
          <div className="relative">
            <div className="relative aspect-[4/5] rounded-lg overflow-hidden">
              <Image
                src="/images/jon-and-brandi-cooney.png"
                alt="Jon and Brandi Cooney with their German Shepherds"
                fill
                className="object-cover"
              />
            </div>
            {/* Decorative element - hidden on mobile to prevent overflow */}
            <div className="hidden sm:block absolute -bottom-6 -right-6 w-48 h-48 bg-accent/10 rounded-lg -z-10" />
            <div className="hidden sm:block absolute -top-6 -left-6 w-32 h-32 bg-primary/10 rounded-lg -z-10" />
          </div>

          {/* Content */}
          <div>
            <p className="text-sm uppercase tracking-[0.2em] text-accent mb-4">
              Meet the Cooneys
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-foreground text-balance">
              Building More Than Homes, Building Relationships
            </h2>
            <div className="mt-6 space-y-4 text-muted-foreground leading-relaxed">
              <p>
                We&apos;re Jon and Brandi Cooney, the husband-and-wife team behind Northbound Builders. 
                Based right here in Battle Creek, Michigan, we started this company with a simple belief: 
                every homeowner deserves a builder who cares as much about their project as they do.
              </p>
              <p>
                When we&apos;re not busy transforming homes, you&apos;ll find us exploring 
                the beautiful Michigan countryside with our two German Shepherds, Benny and Bella. That same love for this 
                region drives us to help our neighbors create spaces they&apos;ll cherish for years to come.
              </p>
              <p>
                We believe in honest communication, transparent pricing, and delivering results that 
                exceed expectations. Every deck we build, every bathroom we remodel, and every home 
                we construct carries our name and our reputation.
              </p>
            </div>

            {/* Values */}
            <div className="mt-10 grid grid-cols-2 gap-6">
              {values.map((value) => (
                <div key={value.title} className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <value.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground">{value.title}</h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      {value.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
