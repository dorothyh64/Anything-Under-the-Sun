import { MapPin, CheckCircle2 } from "lucide-react"

const serviceAreas = [
  "Battle Creek",
  "Kalamazoo",
  "Portage",
  "Marshall",
  "Coldwater",
  "Hastings",
  "Albion",
  "Sturgis",
  "Three Rivers",
  "Plainwell",
  "Paw Paw",
  "Schoolcraft",
]

export function ServiceAreaSection() {
  return (
    <section className="py-24 bg-muted">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div>
            <p className="text-sm uppercase tracking-[0.2em] text-accent mb-4">
              Where We Work
            </p>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-foreground text-balance">
              Proudly Serving Southwest Michigan
            </h2>
            <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
              Based in Battle Creek, we serve homeowners throughout the greater 
              Southwest Michigan region. Our commitment to quality doesn&apos;t change 
              regardless of project location.
            </p>

            <div className="mt-8 grid grid-cols-2 sm:grid-cols-3 gap-4">
              {serviceAreas.map((area) => (
                <div key={area} className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-accent flex-shrink-0" />
                  <span className="text-foreground text-sm">{area}</span>
                </div>
              ))}
            </div>

            <p className="mt-8 text-muted-foreground">
              Don&apos;t see your area listed? Contact us anyway! We regularly take on 
              projects throughout Southwest Michigan and beyond.
            </p>
          </div>

          {/* Google Map */}
          <div className="relative">
            <div className="aspect-square rounded-lg overflow-hidden bg-card shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d94548.82982564475!2d-85.25138565!3d42.3211522!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88179e6cb1c1e3e9%3A0x5c7c0a5f3e5f3f3f!2sBattle%20Creek%2C%20MI!5e0!3m2!1sen!2sus!4v1699999999999!5m2!1sen!2sus"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Northbound Builders Location - Battle Creek, MI"
                className="w-full h-full sepia-[0.35] saturate-[1.1] hue-rotate-[50deg] brightness-[0.95]"
              />
            </div>
            <div className="absolute bottom-2 left-2 right-2 sm:bottom-4 sm:left-4 sm:right-4 bg-card/95 backdrop-blur-sm rounded-lg p-3 sm:p-4 shadow-lg">
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-serif text-base sm:text-lg text-foreground">
                    Battle Creek, MI
                  </h3>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Our Home Base - Serving 50+ mile radius
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
