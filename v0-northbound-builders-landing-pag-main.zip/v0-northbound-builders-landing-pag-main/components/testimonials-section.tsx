import { Star, Quote } from "lucide-react"

const testimonials = [
  {
    name: "Sarah M.",
    location: "Battle Creek, MI",
    rating: 5,
    text: "Northbound Builders transformed our outdated deck into an absolute showpiece. Their attention to detail is incredible, and they kept us informed every step of the way. Couldn't be happier with the results!",
    project: "Deck Renovation",
  },
  {
    name: "Michael & Lisa T.",
    location: "Portage, MI",
    rating: 5,
    text: "We hired Northbound Builders for our master bathroom remodel, and wow! The quality of work exceeded our expectations. Jon treated our home with respect and delivered on time and on budget.",
    project: "Bathroom Remodel",
  },
  {
    name: "David K.",
    location: "Kalamazoo, MI",
    rating: 5,
    text: "The paver patio and fire pit they installed is now my favorite spot to relax. Professional, honest, and truly skilled at their craft. I've already recommended Northbound Builders to three neighbors.",
    project: "Patio & Fire Pit",
  },
  {
    name: "Jennifer R.",
    location: "Marshall, MI",
    rating: 5,
    text: "From the initial consultation to the final walkthrough, working with Northbound Builders was a pleasure. Jon transformed our dated sunroom into a cozy retreat we use year-round.",
    project: "Sunroom Renovation",
  },
]

export function TestimonialsSection() {
  return (
    <section id="testimonials" className="py-24 bg-primary">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <p className="text-sm uppercase tracking-[0.2em] text-primary-foreground/70 mb-4">
            Client Stories
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-primary-foreground text-balance">
            What Our Clients Say
          </h2>
          <p className="mt-4 text-primary-foreground/80 text-lg leading-relaxed">
            Don&apos;t just take our word for it. Here&apos;s what homeowners across 
            Southwest Michigan have to say about working with us.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial) => (
            <div
              key={testimonial.name}
              className="bg-card rounded-lg p-8 relative"
            >
              <Quote className="absolute top-6 right-6 h-8 w-8 text-muted/50" />
              <div className="flex items-center gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={`star-${testimonial.name}-${i}`}
                    className="h-4 w-4 fill-accent text-accent"
                  />
                ))}
              </div>
              <p className="text-foreground leading-relaxed mb-6">
                &ldquo;{testimonial.text}&rdquo;
              </p>
              <div className="border-t border-border pt-4">
                <p className="font-medium text-foreground">{testimonial.name}</p>
                <p className="text-sm text-muted-foreground">
                  {testimonial.location} &bull; {testimonial.project}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
