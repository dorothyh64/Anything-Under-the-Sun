"use client"

import React from "react"

import { useState } from "react"
import { Phone, Mail, Clock, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

const contactInfo = [
  {
    icon: Phone,
    title: "Phone",
    value: "(269) 355-0968",
    href: "tel:+12693550968",
  },
  {
    icon: Mail,
    title: "Email",
    value: "info@northboundbuilders.com",
    href: "mailto:info@northboundbuilders.com",
  },
  {
    icon: Clock,
    title: "Hours",
    value: "Mon-Sat: 7am - 6pm",
    href: null,
  },
]

export function ContactSection() {
  const [formState, setFormState] = useState({
    name: "",
    email: "",
    phone: "",
    projectType: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setIsSubmitted(true)
  }

  return (
    <section id="contact" className="py-24 bg-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <p className="text-sm uppercase tracking-[0.2em] text-accent mb-4">
            Get In Touch
          </p>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-foreground text-balance">
            Ready to Start Your Project?
          </h2>
          <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
            Tell us about your vision and we&apos;ll provide a free consultation 
            and detailed estimate. No pressure, just honest advice.
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact Info */}
          <div className="space-y-6">
            {contactInfo.map((item) => (
              <div
                key={item.title}
                className="flex items-start gap-4 p-4 rounded-lg bg-muted"
              >
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{item.title}</p>
                  {item.href ? (
                    <a
                      href={item.href}
                      className="text-foreground font-medium hover:text-primary transition-colors"
                    >
                      {item.value}
                    </a>
                  ) : (
                    <p className="text-foreground font-medium">{item.value}</p>
                  )}
                </div>
              </div>
            ))}

            <div className="p-6 rounded-lg bg-primary text-primary-foreground">
              <h3 className="font-serif text-xl mb-2">Free Estimates</h3>
              <p className="text-primary-foreground/80 text-sm leading-relaxed">
                We offer free on-site consultations for all projects. 
                Let us visit your home and provide a detailed, 
                no-obligation estimate.
              </p>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            {isSubmitted ? (
              <div className="h-full flex items-center justify-center p-12 rounded-lg bg-muted border border-border">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mx-auto mb-4">
                    <Send className="h-8 w-8 text-accent" />
                  </div>
                  <h3 className="font-serif text-2xl text-foreground mb-2">
                    Message Sent!
                  </h3>
                  <p className="text-muted-foreground">
                    Thank you for reaching out. We&apos;ll get back to you within 24 hours.
                  </p>
                </div>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="p-8 rounded-lg bg-card border border-border"
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      placeholder="John Smith"
                      value={formState.name}
                      onChange={(e) =>
                        setFormState({ ...formState, name: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="john@example.com"
                      value={formState.email}
                      onChange={(e) =>
                        setFormState({ ...formState, email: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="(269) 555-0123"
                      value={formState.phone}
                      onChange={(e) =>
                        setFormState({ ...formState, phone: e.target.value })
                      }
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="projectType">Project Type</Label>
                    <select
                      id="projectType"
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-foreground text-sm"
                      value={formState.projectType}
                      onChange={(e) =>
                        setFormState({ ...formState, projectType: e.target.value })
                      }
                      required
                    >
                      <option value="">Select a project type</option>
                      <option value="deck">Custom Deck</option>
                      <option value="bathroom">Bathroom Remodel</option>
                      <option value="kitchen">Kitchen Renovation</option>
                      <option value="patio">Patio & Hardscaping</option>
                      <option value="roofing">Roofing & Siding</option>
                      <option value="new-home">New Home Construction</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div className="sm:col-span-2 space-y-2">
                    <Label htmlFor="message">Tell Us About Your Project</Label>
                    <Textarea
                      id="message"
                      placeholder="Describe your project, timeline, and any specific requirements..."
                      rows={5}
                      value={formState.message}
                      onChange={(e) =>
                        setFormState({ ...formState, message: e.target.value })
                      }
                      required
                    />
                  </div>
                </div>
                <Button
                  type="submit"
                  size="lg"
                  className="w-full mt-6"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Sending..." : "Send Message"}
                </Button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
